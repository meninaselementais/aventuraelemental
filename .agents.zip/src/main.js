import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { FBXLoader } from 'three/addons/loaders/FBXLoader.js';
import * as SkeletonUtils from 'three/addons/utils/SkeletonUtils.js';
import './style.css';
import { SUBJECTS, getQuestion, normalizeAnswer } from './questions.js';

const $ = (selector) => document.querySelector(selector);
const ui = {
  start: $('#start-screen'), startButton: $('#start-button'), hud: $('#hud'), level: $('#level-value'),
  subjectScreen: $('#subject-screen'), subjectList: $('#subject-list'), subjectLabel: $('#subject-label'),
  roomLabel: $('#room-label'), dots: $('#room-dots'), guide: $('#guide'), guideText: $('#guide-text'),
  face: $('#lia-face'), crosshair: $('#crosshair'), interact: $('#interact-button'), controls: $('#touch-controls'),
  math: $('#math-modal'), question: $('#question'), answers: $('#answers'), hearts: $('#hearts'), feedback: $('#feedback'),
  operationHint: $('#operation-hint'), transition: $('#room-transition'),
  typedAnswer: $('#typed-answer'), answerInput: $('#answer-input'),
  closeMath: $('#close-math'), levelModal: $('#level-modal'), newLevel: $('#new-level'), continueButton: $('#continue-button'),
  completionEyebrow: $('#completion-eyebrow'), completionTitle: $('#completion-title'), completionText: $('#completion-text'),
  joystick: $('#joystick-zone'), knob: $('#joystick-knob'), lookZone: $('#look-zone'), sound: $('#sound-button'),
  playerName: $('#player-name'), playerLogin: $('#player-login-button'), playerMessage: $('#player-login-message'),
  hudPlayer: $('#hud-player'), rankingButton: $('#ranking-button'), subjectRankingButton: $('#subject-ranking-button'),
  rankingModal: $('#ranking-modal'), rankingList: $('#ranking-list'), closeRanking: $('#close-ranking'),
  jump: $('#jump-button'), slowStep: $('#slow-step-button')
};

let scene, camera, renderer, clock;
let doorGroup, doorPivot, panelGroup, doorGlow, characterGroup;
let leftArm, rightArm, leftLeg, rightLeg, walkTime = 0;
let elementalTemplate = null, elementalLoading = false, elementalLoadFailed = false;
let elementalAnimations = [], characterMixer = null, walkingAction = null, slowWalkingAction = null, idleAction = null, jumpingAction = null;
let walkBlend = 0, slowWalkBlend = 0, idleBlend = 1, jumpBlend = 0, scriptedWalk = false;
let started = false, subjectChosen = false, modalOpen = false, changingRoom = false, soundOn = true;
let roomNumber = 1, level = 1, roomInLevel = 1, attempts = 0;
let problem = null, doorSide = 0, doorDistance = Infinity;
let currentSubject = 'math', subjectFinished = false;
let playerName = '', playerConnected = false, newRecordThisLevel = false;
let pendingProgress = Promise.resolve(false);
let jumpActive = false, jumpElapsed = 0, jumpOffset = 0, jumpVelocity = 0, jumpDuration = .48, mobileSlowMode = false;
let guideHideTimer = null, guideRemoveTimer = null;
const JUMP_ASCEND_DURATION = .28;
const JUMP_DESCEND_DURATION = .20;
const JUMP_HEIGHT = .52;
const JUMP_FORWARD_SPEED_START = 5.2;
const JUMP_FORWARD_SPEED_END = 1.6;
let yaw = 0, pitch = 0;
const keys = {};
const MOVEMENT_KEYS = ['KeyW', 'ArrowUp', 'KeyS', 'ArrowDown', 'KeyA', 'ArrowLeft', 'KeyD', 'ArrowRight'];
let lastDirectionalKeySignal = 0;
const STUCK_KEY_TIMEOUT = 900;
let joystickPointerId = null;
const moveInput = { x: 0, y: 0 };
const velocity = new THREE.Vector2();
const jumpDirection = new THREE.Vector2(0, -1);
const wrongChoices = new Set();
const debugMode = import.meta.env.DEV && new URLSearchParams(location.search).has('debug');
const PLAYER_STORAGE_KEY = 'elementais-player-name';
const player = { position: new THREE.Vector3(0, 0, 2.2), radius: .42 };
const THEMES = [
  { name: 'Corredores Dourados', wall: 0xcfc5a0, floor: 0x756b55, ceiling: 0xe7dfc9, accent: 0xf0a849, fog: 0x8b7a58, light: 0xffe5a1, kind: 'classic' },
  { name: 'Templo do Fogo', wall: 0x542d25, floor: 0x241b1b, ceiling: 0x2f2020, accent: 0xff642e, fog: 0x3e1612, light: 0xff6b30, kind: 'fire' },
  { name: 'Câmara das Águas', wall: 0x397f91, floor: 0x174a5b, ceiling: 0x265d70, accent: 0x46e0e5, fog: 0x123e57, light: 0x78edff, kind: 'water' },
  { name: 'Mina de Carvão', wall: 0x34363b, floor: 0x17191d, ceiling: 0x202226, accent: 0xffb23f, fog: 0x111318, light: 0xffc56a, kind: 'coal' },
  { name: 'Gruta de Cristal', wall: 0x594c78, floor: 0x28233e, ceiling: 0x39304e, accent: 0xb58cff, fog: 0x211a38, light: 0xc6a8ff, kind: 'crystal' }
];
let roomSpec = createRoomSpec(1);

function createRoomSpec(number) {
  const sizes = [
    { halfX: 6, halfZ: 6, height: 3.4, shape: 'square' },
    { halfX: 7.5, halfZ: 5, height: 4.1, shape: 'rectangle' },
    { halfX: 6.4, halfZ: 6.4, height: 4, shape: 'round' },
    { halfX: 4.8, halfZ: 4.8, height: 3.2, shape: 'small' },
    { halfX: 8, halfZ: 7, height: 4.6, shape: 'large' }
  ];
  return { ...sizes[(number - 1) % sizes.length], theme: THEMES[(number - 1) % THEMES.length], doorScale: .86 + Math.random() * .3 };
}

function init3D() {
  scene = new THREE.Scene();
  scene.background = new THREE.Color(0x17132a);
  scene.fog = new THREE.FogExp2(0x241d38, .025);
  camera = new THREE.PerspectiveCamera(70, innerWidth / innerHeight, .1, 60);
  camera.rotation.order = 'YXZ';
  renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
  renderer.setPixelRatio(Math.min(devicePixelRatio, 1.7));
  renderer.setSize(innerWidth, innerHeight);
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  $('#game').appendChild(renderer.domElement);
  clock = new THREE.Clock();
  buildRoom();
  addLights();
  updateCamera();
  animate();
}

function mat(color, roughness = .8, emissive = 0x000000) {
  return new THREE.MeshStandardMaterial({ color, roughness, emissive, emissiveIntensity: emissive ? .45 : 0 });
}

function addBox(name, size, position, material, parent = scene) {
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(...size), material);
  mesh.name = name;
  mesh.position.set(...position);
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  parent.add(mesh);
  return mesh;
}

function buildRoom() {
  while (scene.children.length) scene.remove(scene.children[0]);
  const theme = roomSpec.theme;
  scene.background = new THREE.Color(theme.fog);
  scene.fog = new THREE.FogExp2(theme.fog, roomSpec.shape === 'large' ? .018 : .026);
  const wallMat = mat(theme.wall);
  const floorMat = mat(theme.floor, .96);
  const ceilingMat = mat(theme.ceiling, .9);
  const trimMat = mat(theme.kind === 'coal' ? 0x15171a : 0x453754);
  const { halfX, halfZ, height } = roomSpec;

  if (roomSpec.shape === 'round') {
    const radius = halfX;
    const floor = new THREE.Mesh(new THREE.CylinderGeometry(radius, radius, .2, 40), floorMat);
    floor.position.y = -.1; floor.receiveShadow = true; scene.add(floor);
    const ceiling = new THREE.Mesh(new THREE.CylinderGeometry(radius, radius, .16, 40), ceilingMat);
    ceiling.position.y = height; ceiling.receiveShadow = true; scene.add(ceiling);
    const segments = 32, arc = (Math.PI * 2 * radius) / segments;
    for (let i = 0; i < segments; i++) {
      const angle = i / segments * Math.PI * 2;
      const wall = addBox('roundWall', [arc + .08, height, .28], [Math.sin(angle) * radius, height / 2, Math.cos(angle) * radius], wallMat);
      wall.rotation.y = angle;
    }
  } else {
    addBox('floor', [halfX * 2, .2, halfZ * 2], [0, -.1, 0], floorMat);
    addBox('ceiling', [halfX * 2, .16, halfZ * 2], [0, height, 0], ceilingMat);
    addBox('wallS', [halfX * 2, height, .25], [0, height / 2, halfZ], wallMat);
    addBox('wallN', [halfX * 2, height, .25], [0, height / 2, -halfZ], wallMat);
    addBox('wallW', [.25, height, halfZ * 2], [-halfX, height / 2, 0], wallMat);
    addBox('wallE', [.25, height, halfZ * 2], [halfX, height / 2, 0], wallMat);
  }

  for (let z = -halfZ + 1.5; z < halfZ; z += 2.5) {
    const beam = addBox('ceilingBeam', [Math.max(2, halfX * 1.8), .12, .1], [0, height - .12, z], trimMat);
    beam.castShadow = false;
  }
  for (let x = -halfX + 1.5; x < halfX; x += 3) {
    const fixture = addBox('light', [1.5, .05, .48], [x, height - .22, 0], mat(theme.light, .35, theme.light));
    fixture.castShadow = false;
  }
  addThemeDetails(theme);
  createDoor(doorSide, theme.accent);
  createElemental();
}

function addThemeDetails(theme) {
  const { halfX, halfZ, height } = roomSpec;
  if (theme.kind === 'fire') {
    for (const x of [-halfX + .8, halfX - .8]) {
      for (const z of [-halfZ * .45, halfZ * .45]) {
        const flame = new THREE.Mesh(new THREE.ConeGeometry(.28, .95, 7), mat(0xff632e, .35, 0xff3b16));
        flame.position.set(x, .48, z); flame.castShadow = true; scene.add(flame);
        const glow = new THREE.PointLight(0xff5428, 9, 4, 2); glow.position.set(x, .8, z); scene.add(glow);
      }
    }
  } else if (theme.kind === 'water') {
    for (let i = 0; i < 7; i++) {
      const ring = new THREE.Mesh(new THREE.TorusGeometry(.25 + (i % 3) * .12, .025, 6, 20), mat(0x75f2ff, .2, 0x28aabd));
      ring.rotation.x = Math.PI / 2; ring.position.set(-halfX * .7 + (i * 1.73) % (halfX * 1.4), .025, -halfZ * .6 + (i * 2.1) % (halfZ * 1.2)); scene.add(ring);
    }
  } else if (theme.kind === 'coal') {
    for (let i = 0; i < 10; i++) {
      const rock = new THREE.Mesh(new THREE.DodecahedronGeometry(.22 + (i % 3) * .08, 0), mat(i % 2 ? 0x25282d : 0x111216, 1));
      const side = i % 2 ? -1 : 1; rock.position.set(side * (halfX - .55), .2, -halfZ + 1 + (i * 1.37) % (halfZ * 1.7)); rock.rotation.set(i, i * .7, 0); rock.castShadow = true; scene.add(rock);
    }
  } else if (theme.kind === 'crystal') {
    for (let i = 0; i < 8; i++) {
      const crystal = new THREE.Mesh(new THREE.ConeGeometry(.18 + (i % 2) * .09, .8 + (i % 3) * .3, 6), mat(0x9d72ed, .25, 0x6a39c5));
      const side = i % 2 ? -1 : 1; crystal.position.set(side * (halfX - .7), crystal.geometry.parameters.height / 2, -halfZ * .65 + (i * 1.8) % (halfZ * 1.3)); crystal.castShadow = true; scene.add(crystal);
    }
  } else if (roomNumber % 2 === 0) {
    addBox('pillar', [.7, height, .7], [-Math.min(2.5, halfX - 1.2), height / 2, .7], mat(theme.wall));
  }
}

function prepareElementalModel(model) {
  model.rotation.y = Math.PI;
  model.updateMatrixWorld(true);

  let bounds = new THREE.Box3().setFromObject(model);
  const size = bounds.getSize(new THREE.Vector3());
  model.scale.setScalar(2.15 / Math.max(size.y, .001));
  model.updateMatrixWorld(true);

  bounds = new THREE.Box3().setFromObject(model);
  const center = bounds.getCenter(new THREE.Vector3());
  model.position.x -= center.x;
  model.position.y -= bounds.min.y;
  model.position.z -= center.z;
  model.traverse((part) => {
    if (!part.isMesh) return;
    part.castShadow = true;
    part.receiveShadow = true;
    part.frustumCulled = true;
  });
  return model;
}

function makeAnimationInPlace(sourceClip) {
  const clip = sourceClip.clone();
  const hipsPosition = clip.tracks.find((track) => track.name.toLowerCase().includes('hips') && track.name.endsWith('.position'));
  if (hipsPosition) {
    const startX = hipsPosition.values[0];
    const startZ = hipsPosition.values[2];
    for (let i = 0; i < hipsPosition.values.length; i += 3) {
      hipsPosition.values[i] = startX;
      hipsPosition.values[i + 2] = startZ;
    }
  }
  return clip;
}

function attachElementalModel(target) {
  if (!elementalTemplate || !target) return;
  const model = SkeletonUtils.clone(elementalTemplate);
  model.name = 'Elemental3D';
  target.add(model);
  characterMixer = null;
  walkingAction = null;
  slowWalkingAction = null;
  idleAction = null;
  jumpingAction = null;
  walkBlend = 0;
  slowWalkBlend = 0;
  idleBlend = 1;
  jumpBlend = 0;
  if (elementalAnimations[0]) {
    characterMixer = new THREE.AnimationMixer(model);
    walkingAction = characterMixer.clipAction(elementalAnimations[0]);
    walkingAction.enabled = true;
    walkingAction.setEffectiveWeight(0);
    walkingAction.play();
    if (elementalAnimations[1]) {
      slowWalkingAction = characterMixer.clipAction(elementalAnimations[1]);
      slowWalkingAction.enabled = true;
      slowWalkingAction.setEffectiveWeight(0);
      slowWalkingAction.play();
    }
    if (elementalAnimations[2]) {
      idleAction = characterMixer.clipAction(elementalAnimations[2]);
      idleAction.enabled = true;
      idleAction.setEffectiveWeight(1);
      idleAction.play();
    }
    if (elementalAnimations[3]) {
      jumpingAction = characterMixer.clipAction(elementalAnimations[3]);
      jumpingAction.enabled = true;
      jumpingAction.clampWhenFinished = false;
      jumpingAction.setLoop(THREE.LoopOnce, 1);
      jumpingAction.setEffectiveWeight(0);
      jumpDuration = JUMP_ASCEND_DURATION + JUMP_DESCEND_DURATION;
      jumpingAction.setEffectiveTimeScale(elementalAnimations[3].duration / jumpDuration);
    }
  }
}

function loadStaticElementalFallback() {
  new GLTFLoader().load(
    '/assets/elemental-character.glb',
    (gltf) => {
      elementalAnimations = (gltf.animations ?? []).map(makeAnimationInPlace);
      elementalTemplate = prepareElementalModel(gltf.scene);
      elementalLoading = false;
      attachElementalModel(characterGroup);
    },
    undefined,
    (error) => {
      console.error('Nao foi possivel carregar a personagem reserva.', error);
      elementalLoading = false;
      elementalLoadFailed = true;
      if (characterGroup) scene.remove(characterGroup);
      createProceduralElemental();
    }
  );
}

function createElemental() {
  characterGroup = new THREE.Group();
  characterGroup.name = 'ElementalPlayer';
  characterGroup.position.copy(player.position);
  scene.add(characterGroup);

  // O modelo recebido não possui esqueleto. Estes controles preservam o
  // balanço suave do movimento enquanto o corpo inteiro acompanha os passos.
  leftArm = new THREE.Group(); rightArm = new THREE.Group();
  leftLeg = new THREE.Group(); rightLeg = new THREE.Group();
  characterGroup.add(leftArm, rightArm, leftLeg, rightLeg);

  if (elementalTemplate) {
    attachElementalModel(characterGroup);
    return;
  }
  if (elementalLoading || elementalLoadFailed) return;

  elementalLoading = true;
  new FBXLoader().load(
    '/assets/elemental-walking.fbx',
    (fbx) => {
      const finishLoading = (slowAnimations = [], idleAnimations = [], jumpAnimations = []) => {
        const normalClip = (fbx.animations ?? [])[0] ?? null;
        const slowClip = slowAnimations[0] ?? null;
        const idleClip = idleAnimations[0] ?? null;
        const jumpClip = jumpAnimations[0] ?? null;
        elementalAnimations = [normalClip, slowClip, idleClip, jumpClip].map((clip) => clip ? makeAnimationInPlace(clip) : null);
        elementalTemplate = prepareElementalModel(fbx);
        elementalLoading = false;
        attachElementalModel(characterGroup);
      };
      const loadClip = (url, label) => fetch(url)
        .then((response) => {
          if (!response.ok) throw new Error(`${response.status} ${response.statusText}`);
          return response.json();
        })
        .then((data) => THREE.AnimationClip.parse(data))
        .catch((error) => {
          console.warn(`${label} indisponivel.`, error);
          return null;
        });
      Promise.all([
        loadClip('/assets/elemental-slow-walking.json', 'Caminhada lenta'),
        loadClip('/assets/elemental-idle.json', 'Animacao parada'),
        loadClip('/assets/elemental-jumping.json', 'Animacao de pulo')
      ]).then(([slowClip, idleClip, jumpClip]) => finishLoading(
        slowClip ? [slowClip] : [],
        idleClip ? [idleClip] : [],
        jumpClip ? [jumpClip] : []
      ));
    },
    undefined,
    (error) => {
      console.error('Não foi possível carregar a personagem 3D.', error);
      loadStaticElementalFallback();
    }
  );
}

function createProceduralElemental() {
  characterGroup = new THREE.Group();
  characterGroup.position.copy(player.position);

  const skin = mat(0xd9955f, .68);
  const orange = mat(0xe94f0b, .62);
  const orangeLight = mat(0xff741a, .58);
  const olive = mat(0x667044, .82);
  const oliveDark = mat(0x28351f, .9);
  const leather = mat(0x43291d, .76);
  const leatherLight = mat(0x70462c, .7);
  const red = mat(0x9f211d, .76);
  const eyeGreen = mat(0x2a8d43, .35, 0x0d3517);
  const black = mat(0x171313, .55);
  const glass = mat(0x25d6c8, .18, 0x0e8d8a);
  glass.side = THREE.DoubleSide;
  const brass = mat(0x8a5a24, .4);
  const rope = mat(0x7f5c31, 1);

  const part = (geometry, material, position, parent = characterGroup) => {
    const mesh = new THREE.Mesh(geometry, material);
    mesh.position.set(...position); mesh.castShadow = true; mesh.receiveShadow = true; parent.add(mesh); return mesh;
  };
  const block = (size, material, position, parent = characterGroup) => part(new THREE.BoxGeometry(...size), material, position, parent);

  // Proporções blocadas de brinquedo, como na referência enviada.
  block([.72, .7, .38], olive, [0, 1.08, 0]);
  block([.74, .14, .42], leather, [0, .79, 0]);
  block([.66, .25, .38], oliveDark, [0, .68, 0]);
  block([.15, .62, .045], leatherLight, [-.23, 1.12, -.225]);
  block([.15, .62, .045], leatherLight, [.23, 1.12, -.225]);
  block([.28, .24, .14], leather, [.48, .8, -.03]);
  block([.23, .2, .12], leatherLight, [-.47, .83, -.05]);
  block([.15, .15, .06], brass, [0, .79, -.25]);
  block([.07, .07, .075], black, [0, .79, -.29]);
  for (const y of [.97, 1.13, 1.29]) part(new THREE.SphereGeometry(.027, 7, 5), brass, [0, y, -.22]);

  // Cabeça quadrada, cabelo curto laranja, olhos verdes e sardas.
  block([.64, .62, .58], skin, [0, 1.73, -.02]);
  part(new THREE.SphereGeometry(.39, 10, 8), orange, [0, 1.9, .04]);
  block([.18, .48, .46], orange, [-.34, 1.74, .02]);
  block([.18, .48, .46], orange, [.34, 1.74, .02]);
  block([.55, .2, .2], orange, [0, 1.98, .16]);
  const hairTips = [[-.36,1.55,-.02,-.25],[.36,1.55,-.02,.25],[-.23,1.96,-.3,-.3],[.04,2.0,-.32,.15],[.26,1.94,-.3,.35]];
  hairTips.forEach(([x,y,z,r]) => { const strand = part(new THREE.ConeGeometry(.09, .34, 6), orangeLight, [x,y,z]); strand.rotation.z = r; });
  block([.08, .13, .035], black, [-.14, 1.77, -.32]);
  block([.08, .13, .035], black, [.14, 1.77, -.32]);
  block([.045, .09, .018], eyeGreen, [-.14, 1.77, -.345]);
  block([.045, .09, .018], eyeGreen, [.14, 1.77, -.345]);
  const smile = part(new THREE.TorusGeometry(.09, .016, 5, 12, Math.PI), black, [0, 1.61, -.32]);
  smile.rotation.z = Math.PI;
  for (const x of [-.2,-.15,.15,.2]) part(new THREE.SphereGeometry(.012, 6, 4), leatherLight, [x, 1.64 + Math.abs(x)*.08, -.325]);

  // Lenço vermelho e óculos de aviadora com lentes turquesa.
  block([.42, .13, .08], red, [0, 1.4, -.23]);
  const scarfTip = part(new THREE.ConeGeometry(.2, .34, 4), red, [0, 1.3, -.05]); scarfTip.rotation.y = Math.PI / 4;
  block([.66, .07, .08], leather, [0, 2.04, -.02]);
  for (const x of [-.17, .17]) {
    part(new THREE.TorusGeometry(.145, .045, 7, 16), brass, [x, 2.08, -.24]);
    part(new THREE.CircleGeometry(.105, 16), glass, [x, 2.08, -.285]);
  }
  block([.1, .05, .06], leather, [0, 2.08, -.25]);

  leftArm = new THREE.Group(); rightArm = new THREE.Group();
  leftArm.position.set(-.47, 1.31, 0); rightArm.position.set(.47, 1.31, 0);
  block([.26, .25, .34], olive, [0, -.1, 0], leftArm); block([.26, .25, .34], olive, [0, -.1, 0], rightArm);
  block([.24, .42, .3], skin, [0, -.42, 0], leftArm); block([.24, .42, .3], skin, [0, -.42, 0], rightArm);
  block([.26, .12, .32], leather, [0, -.32, 0], leftArm); block([.28, .13, .34], leather, [0, -.33, 0], rightArm);
  block([.23, .22, .31], skin, [0, -.68, -.02], leftArm); block([.23, .22, .31], skin, [0, -.68, -.02], rightArm);
  block([.2, .18, .07], leather, [0, -.33, -.2], rightArm);
  block([.14, .12, .035], glass, [0, -.33, -.245], rightArm);
  characterGroup.add(leftArm, rightArm);

  leftLeg = new THREE.Group(); rightLeg = new THREE.Group();
  leftLeg.position.set(-.2, .65, 0); rightLeg.position.set(.2, .65, 0);
  block([.28, .28, .34], skin, [0, -.16, 0], leftLeg); block([.28, .28, .34], skin, [0, -.16, 0], rightLeg);
  block([.32, .48, .39], leather, [0, -.48, 0], leftLeg); block([.32, .48, .39], leather, [0, -.48, 0], rightLeg);
  block([.34, .17, .53], leatherLight, [0, -.67, -.08], leftLeg); block([.34, .17, .53], leatherLight, [0, -.67, -.08], rightLeg);
  for (const leg of [leftLeg, rightLeg]) for (const y of [-.37,-.47,-.57]) block([.2, .025, .025], brass, [0,y,-.21], leg);
  characterGroup.add(leftLeg, rightLeg);

  // Mochila, corda enrolada, bolsa e pequeno frasco de exploradora.
  block([.58, .64, .25], leather, [0, 1.13, .31]);
  block([.38, .16, .07], leatherLight, [0, 1.25, .46]);
  for (const radius of [.16,.2,.24]) part(new THREE.TorusGeometry(radius, .025, 6, 18), rope, [-.48, .82, -.25]);
  const bottle = part(new THREE.CylinderGeometry(.055, .065, .2, 8), brass, [.25, .65, -.27]); bottle.rotation.z = .08;
  block([.09, .05, .07], black, [.25, .77, -.27]);
  scene.add(characterGroup);
}

function addLights() {
  const theme = roomSpec.theme;
  scene.add(new THREE.HemisphereLight(theme.light, theme.floor, theme.kind === 'coal' ? 1.15 : 1.7));
  const key = new THREE.PointLight(theme.light, theme.kind === 'fire' ? 30 : 38, Math.max(roomSpec.halfX, roomSpec.halfZ) * 2.5, 2);
  key.position.set(0, roomSpec.height - .7, 0); key.castShadow = true; scene.add(key);
  const accent = new THREE.PointLight(theme.accent, 16, 9, 2);
  accent.position.set(-Math.min(4, roomSpec.halfX - 1), 1.8, Math.min(3, roomSpec.halfZ - 1)); scene.add(accent);
}

function createDoor(side, accentColor) {
  doorGroup = new THREE.Group();
  panelGroup = new THREE.Group();
  const doorMat = new THREE.MeshPhysicalMaterial({ color: 0x3c3152, roughness: .28, metalness: .35, clearcoat: .75, clearcoatRoughness: .18 });
  const insetMat = new THREE.MeshPhysicalMaterial({ color: 0x211a33, roughness: .38, metalness: .45, clearcoat: .5 });
  const frameMat = new THREE.MeshStandardMaterial({ color: 0x181321, roughness: .35, metalness: .7 });
  const metalMat = new THREE.MeshStandardMaterial({ color: 0xd99835, roughness: .22, metalness: .9, emissive: 0x5d2d08, emissiveIntensity: .25 });
  const panelMat = new THREE.MeshStandardMaterial({ color: accentColor, roughness: .2, metalness: .12, emissive: accentColor, emissiveIntensity: 1.1, side: THREE.DoubleSide });
  const isNorth = side === 0;
  const scale = roomSpec.doorScale;
  const boundaryX = roomSpec.halfX - .18, boundaryZ = roomSpec.halfZ - .18;
  const maxOffset = Math.max(.4, (isNorth ? roomSpec.halfX : roomSpec.halfZ) - 2.5 * scale);
  const offset = Math.sin(roomNumber * 1.91 + side * 2.2 + attempts) * maxOffset * .7;
  const doorPosition = isNorth ? [offset, 1.35 * scale, -boundaryZ] : [side === 1 ? boundaryX : -boundaryX, 1.35 * scale, offset];
  doorGroup.position.set(...doorPosition);
  doorGroup.rotation.y = isNorth ? 0 : side === 1 ? -Math.PI / 2 : Math.PI / 2;
  doorGroup.scale.setScalar(scale);

  doorPivot = new THREE.Group();
  doorPivot.position.set(-.93, 0, 0); doorGroup.add(doorPivot);
  const leaf = new THREE.Group(); leaf.position.x = .93; doorPivot.add(leaf);
  addBox('doorLeaf', [1.86, 2.62, .18], [0, 0, 0], doorMat, leaf);
  addBox('doorInsetTop', [1.38, .78, .07], [0, .63, -.12], insetMat, leaf);
  addBox('doorInsetBottom', [1.38, .82, .07], [0, -.66, -.12], insetMat, leaf);
  for (const x of [-.72, .72]) for (const y of [-1.05, 1.05]) {
    const stud = new THREE.Mesh(new THREE.SphereGeometry(.055, 8, 6), metalMat); stud.position.set(x, y, -.14); leaf.add(stud);
  }
  const handle = new THREE.Mesh(new THREE.CylinderGeometry(.065, .065, .32, 10), metalMat);
  handle.rotation.x = Math.PI / 2; handle.position.set(.58, 0, -.25); handle.castShadow = true; leaf.add(handle);
  addBox('frameTop', [2.35, .22, .35], [0, 1.44, 0], frameMat, doorGroup);
  addBox('frameL', [.22, 2.95, .35], [-1.07, 0, 0], frameMat, doorGroup);
  addBox('frameR', [.22, 2.95, .35], [1.07, 0, 0], frameMat, doorGroup);
  const crown = new THREE.Mesh(new THREE.TorusGeometry(1.07, .09, 7, 24, Math.PI), metalMat);
  crown.position.y = 1.36; crown.rotation.z = Math.PI; doorGroup.add(crown);
  scene.add(doorGroup);

  const panelGap = 1.55 * scale;
  const panelPosition = isNorth ? [THREE.MathUtils.clamp(offset + panelGap, -roomSpec.halfX + .7, roomSpec.halfX - .7), 1.45, -boundaryZ + .12] : [side === 1 ? boundaryX - .12 : -boundaryX + .12, 1.45, THREE.MathUtils.clamp(offset + panelGap, -roomSpec.halfZ + .7, roomSpec.halfZ - .7)];
  panelGroup.position.set(...panelPosition);
  panelGroup.rotation.y = isNorth ? 0 : side === 1 ? -Math.PI / 2 : Math.PI / 2;
  addBox('panelFrame', [1.2, 1.1, .24], [0, 0, 0], frameMat, panelGroup);
  addBox('panelRim', [1.04, .92, .12], [0, 0, .15], metalMat, panelGroup);
  addBox('panelScreen', [.88, .68, .08], [0, .08, .25], panelMat, panelGroup);
  for (let x = -.26; x <= .26; x += .26) addBox('panelButton', [.13, .13, .08], [x, -.31, .31], mat(0xf7e9cf), panelGroup);
  scene.add(panelGroup);
  doorGlow = new THREE.PointLight(accentColor, 12, 4.5, 2);
  doorGlow.position.copy(panelGroup.position); scene.add(doorGlow);
}

function cleanPlayerName(value) {
  return String(value || '').trim().replace(/\s+/g, ' ').slice(0, 24);
}

function setSubjectButtonsEnabled(enabled) {
  ui.subjectList.querySelectorAll('button[data-subject]').forEach(button => { button.disabled = !enabled; });
}

function updatePlayerUI(message = '') {
  ui.hudPlayer.textContent = playerConnected ? `👤 ${playerName}` : 'Sem jogador';
  setSubjectButtonsEnabled(playerConnected);
  ui.playerMessage.className = playerConnected ? 'connected' : message ? 'error' : '';
  ui.playerMessage.textContent = message || (playerConnected ? `Jogador conectado: ${playerName}` : 'Digite seu primeiro nome ou apelido para começar.');
}

function connectPlayer() {
  const name = cleanPlayerName(ui.playerName.value);
  if (name.length < 2) {
    playerConnected = false;
    updatePlayerUI('Digite um nome ou apelido com pelo menos 2 letras.');
    ui.playerName.focus();
    return false;
  }
  playerName = name;
  playerConnected = true;
  ui.playerName.value = name;
  localStorage.setItem(PLAYER_STORAGE_KEY, name);
  updatePlayerUI();
  beep(520, .1);
  return true;
}

function restorePlayer() {
  const savedName = cleanPlayerName(localStorage.getItem(PLAYER_STORAGE_KEY));
  if (savedName.length >= 2) {
    playerName = savedName;
    playerConnected = true;
    ui.playerName.value = savedName;
  }
  updatePlayerUI();
}

function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, character => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[character]);
}

function renderRanking(entries) {
  if (!entries.length) {
    ui.rankingList.innerHTML = '<p class="ranking-status">Ainda não há jogadores no ranking. Seja o primeiro!</p>';
    return;
  }
  const current = playerName.toLocaleLowerCase('pt-BR');
  ui.rankingList.innerHTML = entries.map((entry, index) => {
    const isCurrent = entry.name.toLocaleLowerCase('pt-BR') === current;
    const subjectName = SUBJECTS[entry.subject]?.name || entry.subject;
    return `<div class="ranking-row${isCurrent ? ' me' : ''}">
      <span class="ranking-position">${index + 1}</span>
      <div><div class="ranking-name">${escapeHTML(entry.name)}</div><span class="ranking-subject">${escapeHTML(subjectName)}</span></div>
      <div class="ranking-progress">Nível ${entry.level}<small>${entry.score} de 25 perguntas</small></div>
    </div>`;
  }).join('');
}

async function loadRanking() {
  const response = await fetch('/api/ranking', { cache: 'no-store' });
  if (!response.ok) throw new Error('ranking unavailable');
  const data = await response.json();
  renderRanking(data.entries || []);
}

function openRanking() {
  modalOpen = true;
  stopMovement();
  ui.rankingModal.classList.add('open');
  ui.rankingList.innerHTML = '<p class="ranking-status">Carregando ranking…</p>';
  loadRanking().catch(() => {
    ui.rankingList.innerHTML = '<p class="ranking-status">Não foi possível carregar agora. Verifique se o servidor do jogo está ligado.</p>';
  });
}

function closeRanking() {
  ui.rankingModal.classList.remove('open');
  modalOpen = ui.subjectScreen.classList.contains('open') || ui.levelModal.classList.contains('open');
}

async function saveProgress() {
  if (!playerConnected) return false;
  const score = Math.min(25, (level - 1) * 5 + roomInLevel);
  const response = await fetch('/api/ranking', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name: playerName, subject: currentSubject, score })
  });
  if (!response.ok) throw new Error('progress unavailable');
  const data = await response.json();
  return Boolean(data.newLeader);
}

function openMath() {
  if (changingRoom) return;
  modalOpen = true; stopMovement();
  if (!problem) problem = getQuestion(currentSubject, level, roomInLevel - 1);
  ui.question.textContent = problem.prompt;
  ui.question.classList.toggle('compact', problem.prompt.length > 24);
  ui.operationHint.textContent = problem.hint || SUBJECTS[currentSubject].short;
  ui.answers.innerHTML = '';
  const isTyped = problem.inputMode === 'typed';
  ui.answers.classList.toggle('hidden', isTyped);
  ui.typedAnswer.classList.toggle('hidden', !isTyped);
  if (isTyped) {
    ui.answerInput.value = ''; ui.answerInput.disabled = false;
    const numericAnswer = problem.subject === 'math';
    ui.answerInput.inputMode = numericAnswer ? 'numeric' : 'text';
    ui.answerInput.placeholder = numericAnswer ? 'Digite o número' : 'Digite a resposta';
    setTimeout(() => ui.answerInput.focus(), 280);
  } else {
    problem.choices.forEach(value => {
      const button = document.createElement('button');
      button.className = 'answer-button'; button.textContent = value;
      if (wrongChoices.has(String(value))) { button.classList.add('wrong'); button.disabled = true; }
      button.addEventListener('click', () => checkAnswer(value, button));
      ui.answers.appendChild(button);
    });
  }
  updateHearts();
  ui.feedback.textContent = attempts ? 'A pergunta continua a mesma. Tente novamente.' : isTyped ? 'Digite e confirme sua resposta.' : 'Escolha uma resposta.';
  showGuideMessage('Pense com calma. Você consegue!', 3000, 'lia-face thinking');
  ui.math.classList.add('open');
}

function checkAnswer(value, button) {
  if (changingRoom || (button && button.disabled) || String(value).trim() === '') return;
  const correct = normalizeAnswer(value) === normalizeAnswer(problem.answer);
  if (correct) {
    pendingProgress = saveProgress().then(isNewLeader => {
      newRecordThisLevel = newRecordThisLevel || isNewLeader;
      return isNewLeader;
    }).catch(() => false);
    if (button) button.classList.add('correct');
    [...ui.answers.children].forEach(b => b.disabled = true);
    ui.answerInput.disabled = true;
    ui.feedback.textContent = 'Isso! A porta foi destrancada!';
    showGuideMessage('Resposta certa! Vamos para a próxima sala!', 2500, 'lia-face happy');
    beep(660, .12); setTimeout(() => beep(880, .18), 130);
    setTimeout(unlockDoor, 650);
  } else {
    attempts++; wrongChoices.add(String(value));
    if (button) { button.classList.add('wrong'); button.disabled = true; }
    else { ui.answerInput.classList.add('wrong'); setTimeout(() => ui.answerInput.classList.remove('wrong'), 350); ui.answerInput.select(); }
    updateHearts(); beep(180, .18);
    if (attempts >= 3) {
      ui.feedback.textContent = `A resposta era ${problem.answer}. Uma nova porta vai aparecer!`;
      [...ui.answers.children].forEach(b => b.disabled = true);
      ui.answerInput.disabled = true;
      setTimeout(replaceDoor, 1300);
    } else {
      ui.feedback.textContent = attempts === 1 ? 'Quase! Tente outra vez.' : 'Mais uma tentativa. Você consegue!';
    }
  }
}

function updateHearts() {
  ui.hearts.innerHTML = [0,1,2].map(i => `<span style="opacity:${i < 3 - attempts ? 1 : .18}">♥</span>`).join(' ');
}

function replaceDoor() {
  closeMath();
  changingRoom = true; stopMovement();
  problem = null; attempts = 0; wrongChoices.clear();
  const oldScale = roomSpec.doorScale;
  const start = performance.now();
  function shrink(now) {
    const t = Math.min(1, (now - start) / 420);
    doorGroup.scale.setScalar(oldScale * (1 - t)); panelGroup.scale.setScalar(1 - t);
    if (t < 1) requestAnimationFrame(shrink);
    else {
      scene.remove(doorGroup, panelGroup, doorGlow);
      doorSide = (doorSide + 1 + Math.floor(Math.random() * 2)) % 3;
      roomSpec.doorScale = .82 + Math.random() * .38;
      const targetScale = roomSpec.doorScale;
      createDoor(doorSide, roomSpec.theme.accent);
      doorGroup.scale.setScalar(0); panelGroup.scale.setScalar(0);
      const born = performance.now();
      function grow(time) {
        const q = Math.min(1, (time - born) / 450); const s = 1 - Math.pow(1 - q, 3);
        doorGroup.scale.setScalar(s * targetScale); panelGroup.scale.setScalar(s);
        if (q < 1) requestAnimationFrame(grow); else changingRoom = false;
      }
      requestAnimationFrame(grow);
      showGuideMessage('A porta mudou de lugar. Procure o novo painel!', 4200);
    }
  }
  requestAnimationFrame(shrink);
}

function unlockDoor() {
  ui.math.classList.remove('open'); modalOpen = false; changingRoom = true; stopMovement();
  const start = performance.now();
  function swing(now) {
    const t = Math.min(1, (now - start) / 820);
    const eased = 1 - Math.pow(1 - t, 3);
    doorPivot.rotation.y = -Math.PI * .52 * eased;
    if (t < 1) requestAnimationFrame(swing); else setTimeout(enterDoor, 180);
  }
  requestAnimationFrame(swing);
}

function enterDoor() {
  scriptedWalk = true;
  const startPosition = player.position.clone();
  const outward = doorSide === 0 ? new THREE.Vector3(0, 0, -1) : doorSide === 1 ? new THREE.Vector3(1, 0, 0) : new THREE.Vector3(-1, 0, 0);
  const endPosition = new THREE.Vector3(doorGroup.position.x, 0, doorGroup.position.z).addScaledVector(outward, 1.15);
  const facing = Math.atan2(-outward.x, -outward.z);
  const start = performance.now();
  function walkThrough(now) {
    const t = Math.min(1, (now - start) / 1150);
    const eased = t * t * (3 - 2 * t);
    player.position.lerpVectors(startPosition, endPosition, eased);
    characterGroup.position.copy(player.position);
    const angleDelta = Math.atan2(Math.sin(facing - characterGroup.rotation.y), Math.cos(facing - characterGroup.rotation.y));
    characterGroup.rotation.y += angleDelta * .14;
    walkTime += .13;
    leftArm.rotation.x = Math.sin(walkTime) * .52; rightArm.rotation.x = -Math.sin(walkTime) * .52;
    leftLeg.rotation.x = -Math.sin(walkTime) * .42; rightLeg.rotation.x = Math.sin(walkTime) * .42;
    updateCamera();
    if (t < 1) requestAnimationFrame(walkThrough);
    else {
      scriptedWalk = false;
      ui.transition.classList.add('open');
      setTimeout(async () => { await nextRoom(); setTimeout(() => ui.transition.classList.remove('open'), 260); }, 480);
    }
  }
  requestAnimationFrame(walkThrough);
}

async function nextRoom() {
  await pendingProgress;
  roomNumber++; roomInLevel++;
  if (roomInLevel > 5) {
    if (level >= 5) {
      roomInLevel = 5; subjectFinished = true;
      ui.completionEyebrow.textContent = 'MATÉRIA CONCLUÍDA';
      ui.completionTitle.textContent = newRecordThisLevel ? 'Novo recorde!' : 'Incrível!';
      ui.completionText.textContent = newRecordThisLevel
        ? `Parabéns, ${playerName}! Você atingiu o nível mais alto até agora.`
        : `Você completou os 5 níveis de ${SUBJECTS[currentSubject].name}.`;
      ui.newLevel.textContent = '25 perguntas vencidas!';
      ui.continueButton.textContent = 'Escolher outra matéria →';
    } else {
      level++; roomInLevel = 1; subjectFinished = false;
      ui.completionEyebrow.textContent = 'NÍVEL CONCLUÍDO';
      ui.completionTitle.textContent = newRecordThisLevel ? 'Novo recorde!' : 'Muito bem!';
      ui.completionText.textContent = newRecordThisLevel
        ? `Parabéns, ${playerName}! Você atingiu o nível mais alto até agora.`
        : 'Você respondeu 5 perguntas e chegou ao';
      ui.newLevel.textContent = `Nível ${level}`;
      ui.continueButton.textContent = 'Continuar explorando →';
    }
    ui.levelModal.classList.add('open'); modalOpen = true;
    newRecordThisLevel = false;
  } else buildNextRoom();
  updateHUD();
}

function buildNextRoom() {
  doorSide = Math.floor(Math.random() * 3);
  scriptedWalk = false;
  player.position.set(0, 0, 2.2); yaw = 0; pitch = 0;
  roomSpec = createRoomSpec(roomNumber);
  problem = null; attempts = 0; wrongChoices.clear(); velocity.set(0, 0);
  buildRoom(); addLights(); updateCamera();
  changingRoom = false; modalOpen = false;
  showGuideMessage(`${roomSpec.theme.name}! Encontre a porta trancada.`, 3400);
}

function updateHUD() {
  ui.level.textContent = level;
  ui.hudPlayer.textContent = `👤 ${playerName || 'Jogador'}`;
  ui.subjectLabel.textContent = SUBJECTS[currentSubject].name;
  ui.roomLabel.textContent = `Pergunta ${roomInLevel} de 5`;
  ui.dots.innerHTML = Array.from({ length: 5 }, (_, i) => `<i class="${subjectFinished || i < roomInLevel - 1 ? 'done' : i === roomInLevel - 1 ? 'current' : ''}"></i>`).join('');
}

function showGuideMessage(text, duration = 3600, faceClass = 'lia-face') {
  clearTimeout(guideHideTimer);
  clearTimeout(guideRemoveTimer);
  ui.guideText.textContent = text;
  ui.face.className = faceClass;
  ui.guide.classList.remove('hidden', 'guide-leaving');
  guideHideTimer = setTimeout(() => {
    ui.guide.classList.add('guide-leaving');
    guideRemoveTimer = setTimeout(() => ui.guide.classList.add('hidden'), 320);
  }, duration);
}

function hideGuideMessage() {
  clearTimeout(guideHideTimer);
  clearTimeout(guideRemoveTimer);
  ui.guide.classList.remove('guide-leaving');
  ui.guide.classList.add('hidden');
}

function startSubject(subject) {
  if (!playerConnected) {
    updatePlayerUI('Entre com seu nome antes de escolher uma matéria.');
    ui.playerName.focus();
    return;
  }
  currentSubject = subject; level = 1; roomInLevel = 1; subjectFinished = false; subjectChosen = true;
  newRecordThisLevel = false; pendingProgress = Promise.resolve(false);
  problem = null; attempts = 0; wrongChoices.clear();
  ui.subjectScreen.classList.remove('open');
  [ui.hud, ui.guide, ui.crosshair, ui.controls].forEach(el => el.classList.remove('hidden'));
  buildNextRoom(); updateHUD();
  showGuideMessage(`${SUBJECTS[subject].name}: encontre o primeiro painel!`, 4200);
}

function showSubjectSelection() {
  subjectChosen = false; modalOpen = true; changingRoom = false; stopMovement();
  ui.levelModal.classList.remove('open'); ui.subjectScreen.classList.add('open');
  [ui.hud, ui.guide, ui.crosshair, ui.controls, ui.interact].forEach(el => el.classList.add('hidden'));
  hideGuideMessage();
}

function closeMath() {
  ui.math.classList.remove('open'); modalOpen = false; ui.face.className = 'lia-face'; stopMovement();
}

function triggerJump() {
  if (!started || !subjectChosen || modalOpen || changingRoom || jumpActive) return;
  jumpActive = true;
  jumpElapsed = 0;
  jumpOffset = 0;
  jumpVelocity = JUMP_FORWARD_SPEED_START;
  jumpDirection.set(Math.sin(yaw), -Math.cos(yaw)).normalize();
  velocity.set(0, 0);
  if (jumpingAction) {
    jumpingAction.reset();
    jumpingAction.enabled = true;
    jumpingAction.setLoop(THREE.LoopOnce, 1);
    jumpingAction.setEffectiveTimeScale(elementalAnimations[3].duration / jumpDuration);
    jumpingAction.play();
  }
  playJumpSound();
}

function updateJump(dt) {
  if (!jumpActive) {
    jumpOffset = 0;
    jumpVelocity = 0;
    return;
  }
  jumpElapsed += dt;
  const jumpProgress = THREE.MathUtils.clamp(jumpElapsed / jumpDuration, 0, 1);
  const impulseEase = 1 - (1 - jumpProgress) ** 2;
  jumpVelocity = THREE.MathUtils.lerp(JUMP_FORWARD_SPEED_START, JUMP_FORWARD_SPEED_END, impulseEase);
  if (jumpElapsed <= JUMP_ASCEND_DURATION) {
    const progress = THREE.MathUtils.clamp(jumpElapsed / JUMP_ASCEND_DURATION, 0, 1);
    jumpOffset = JUMP_HEIGHT * (1 - (1 - progress) ** 2);
    return;
  }
  const fallProgress = THREE.MathUtils.clamp((jumpElapsed - JUMP_ASCEND_DURATION) / JUMP_DESCEND_DURATION, 0, 1);
  jumpOffset = JUMP_HEIGHT * (1 - fallProgress ** 1.25);
  if (fallProgress >= 1) {
    jumpActive = false;
    jumpElapsed = 0;
    jumpOffset = 0;
    jumpVelocity = 0;
    velocity.set(0, 0);
    jumpBlend = 0;
    if (jumpingAction) {
      jumpingAction.setEffectiveWeight(0);
      jumpingAction.stop();
    }
  }
}

function updateCharacterAnimation(dt, moving, speed = 0) {
  if (!walkingAction || !characterMixer) return;
  const jumping = jumpActive;
  const slowMode = moving && !scriptedWalk && slowWalkingAction && (keys.ShiftLeft || keys.ShiftRight || mobileSlowMode);
  const normalTarget = moving && !slowMode && !jumping ? 1 : 0;
  const slowTarget = slowMode && !jumping ? 1 : 0;
  const idleTarget = !moving && !jumping ? 1 : 0;
  const jumpTarget = jumping && jumpingAction ? 1 : 0;
  const blendSpeed = 1 - Math.exp(-10 * dt);
  walkBlend += (normalTarget - walkBlend) * blendSpeed;
  slowWalkBlend += (slowTarget - slowWalkBlend) * blendSpeed;
  idleBlend += (idleTarget - idleBlend) * blendSpeed;
  jumpBlend += (jumpTarget - jumpBlend) * blendSpeed;
  walkingAction.setEffectiveWeight(walkBlend);
  walkingAction.setEffectiveTimeScale(moving ? THREE.MathUtils.clamp(speed / 2.3, .65, 1.35) : .8);
  if (slowWalkingAction) {
    slowWalkingAction.setEffectiveWeight(slowWalkBlend);
    slowWalkingAction.setEffectiveTimeScale(moving ? THREE.MathUtils.clamp(speed / 1.45, .75, 1.2) : .8);
  }
  if (idleAction) {
    idleAction.setEffectiveWeight(idleBlend);
    idleAction.setEffectiveTimeScale(1);
  }
  if (jumpingAction) jumpingAction.setEffectiveWeight(jumpBlend);
  characterMixer.update(dt);
}

function updateMovement(dt) {
  updateJump(dt);
  if (!started || modalOpen || changingRoom) {
    velocity.multiplyScalar(Math.exp(-10 * dt));
    updateCharacterAnimation(dt, scriptedWalk, scriptedWalk ? 2.2 : 0);
    relaxWalk(dt); updateCamera(); return;
  }
  if (MOVEMENT_KEYS.some(code => keys[code]) && performance.now() - lastDirectionalKeySignal > STUCK_KEY_TIMEOUT) {
    MOVEMENT_KEYS.forEach(code => { keys[code] = false; });
    velocity.set(0, 0);
  }
  if (joystickPointerId !== null && !ui.joystick.hasPointerCapture(joystickPointerId)) {
    joystickPointerId = null;
    moveInput.x = 0;
    moveInput.y = 0;
    velocity.set(0, 0);
    ui.knob.style.transform = 'translate(-50%,-50%)';
  }
  let forward = moveInput.y + ((keys.KeyW || keys.ArrowUp) ? 1 : 0) - ((keys.KeyS || keys.ArrowDown) ? 1 : 0);
  let strafe = moveInput.x + ((keys.KeyD || keys.ArrowRight) ? 1 : 0) - ((keys.KeyA || keys.ArrowLeft) ? 1 : 0);
  if (jumpActive) {
    forward = 0;
    strafe = 0;
  }
  const length = Math.hypot(forward, strafe); if (length > 1) { forward /= length; strafe /= length; }
  const slowMode = keys.ShiftLeft || keys.ShiftRight || mobileSlowMode;
  const speed = slowMode ? 1.45 : 3.05;
  if (jumpActive) {
    velocity.copy(jumpDirection).multiplyScalar(jumpVelocity);
  } else {
    const targetX = (Math.sin(yaw) * forward + Math.cos(yaw) * strafe) * speed;
    const targetZ = (-Math.cos(yaw) * forward + Math.sin(yaw) * strafe) * speed;
    const responsiveness = length > .02 ? 9 : 6;
    const smooth = 1 - Math.exp(-responsiveness * dt);
    velocity.x += (targetX - velocity.x) * smooth;
    velocity.y += (targetZ - velocity.y) * smooth;
    if (length <= .02 && velocity.lengthSq() < .012) velocity.set(0, 0);
  }
  const dx = velocity.x * dt, dz = velocity.y * dt;
  const next = new THREE.Vector2(player.position.x + dx, player.position.z + dz);
  if (roomSpec.shape === 'round') {
    const maxRadius = roomSpec.halfX - .65;
    if (next.length() > maxRadius) next.setLength(maxRadius);
  } else {
    next.x = THREE.MathUtils.clamp(next.x, -roomSpec.halfX + .55, roomSpec.halfX - .55);
    next.y = THREE.MathUtils.clamp(next.y, -roomSpec.halfZ + .55, roomSpec.halfZ - .55);
  }
  player.position.x = next.x; player.position.z = next.y;
  characterGroup.position.copy(player.position);
  characterGroup.position.y = jumpOffset;
  const moving = velocity.length() > .08;
  if (moving) {
    const targetAngle = Math.atan2(-velocity.x, -velocity.y);
    const angleDelta = Math.atan2(Math.sin(targetAngle - characterGroup.rotation.y), Math.cos(targetAngle - characterGroup.rotation.y));
    characterGroup.rotation.y += angleDelta * (1 - Math.exp(-11 * dt));
    walkTime += dt * (7.5 + velocity.length());
    const stride = Math.min(.52, velocity.length() * .18);
    leftArm.rotation.x = Math.sin(walkTime) * stride; rightArm.rotation.x = -Math.sin(walkTime) * stride;
    leftLeg.rotation.x = -Math.sin(walkTime) * stride * .82; rightLeg.rotation.x = Math.sin(walkTime) * stride * .82;
    if (!walkingAction) characterGroup.position.y = Math.abs(Math.sin(walkTime * 2)) * .025;
  } else relaxWalk(dt);
  updateCharacterAnimation(dt, moving, velocity.length());
  updateCamera();
  const doorPlanar = Math.hypot(player.position.x - doorGroup.position.x, player.position.z - doorGroup.position.z);
  const panelPlanar = Math.hypot(player.position.x - panelGroup.position.x, player.position.z - panelGroup.position.z);
  doorDistance = Math.min(doorPlanar, panelPlanar);
  ui.interact.classList.toggle('hidden', doorDistance > 2.4);
}

function relaxWalk(dt) {
  const settle = Math.exp(-9 * dt);
  if (!leftArm) return;
  leftArm.rotation.x *= settle; rightArm.rotation.x *= settle;
  leftLeg.rotation.x *= settle; rightLeg.rotation.x *= settle;
  if (characterGroup) characterGroup.position.y = jumpOffset;
}

function updateCamera() {
  const behindX = -Math.sin(yaw), behindZ = Math.cos(yaw);
  let wallLimit;
  if (roomSpec.shape === 'round') {
    const radius = roomSpec.halfX - .28;
    const projection = player.position.x * behindX + player.position.z * behindZ;
    wallLimit = -projection + Math.sqrt(Math.max(.1, projection * projection + radius * radius - player.position.x ** 2 - player.position.z ** 2));
  } else {
    const edgeX = roomSpec.halfX - .3, edgeZ = roomSpec.halfZ - .3;
    const limitX = Math.abs(behindX) < .001 ? 99 : (behindX > 0 ? edgeX - player.position.x : -edgeX - player.position.x) / behindX;
    const limitZ = Math.abs(behindZ) < .001 ? 99 : (behindZ > 0 ? edgeZ - player.position.z : -edgeZ - player.position.z) / behindZ;
    wallLimit = Math.min(limitX, limitZ);
  }
  const distance = Math.max(.85, Math.min(4.15, wallLimit));
  camera.position.set(
    player.position.x + behindX * distance,
    2.65 - pitch * 1.45,
    player.position.z + behindZ * distance
  );
  camera.lookAt(player.position.x, 1.12, player.position.z);
}

function stopMovement() {
  Object.keys(keys).forEach(key => keys[key] = false);
  joystickPointerId = null;
  mobileSlowMode = false;
  moveInput.x = 0; moveInput.y = 0; velocity.set(0, 0);
  if (ui.knob) ui.knob.style.transform = 'translate(-50%,-50%)';
  if (ui.slowStep) ui.slowStep.classList.remove('held');
}

function animate() {
  requestAnimationFrame(animate);
  const dt = Math.min(clock.getDelta(), .05); updateMovement(dt);
  if (doorGlow) doorGlow.intensity = 9 + Math.sin(performance.now() * .003) * 3;
  renderer.render(scene, camera);
}

function setupControls() {
  addEventListener('keydown', e => {
    keys[e.code] = true;
    if (MOVEMENT_KEYS.includes(e.code)) lastDirectionalKeySignal = performance.now();
    if (e.code === 'Space' && started && subjectChosen && !modalOpen && !changingRoom) {
      e.preventDefault();
      if (!e.repeat) triggerJump();
    }
    if (debugMode && e.code === 'KeyM') openMath();
    if (debugMode && e.code === 'KeyN' && !changingRoom) { roomNumber++; roomInLevel = roomInLevel % 5 + 1; buildNextRoom(); updateHUD(); }
    if (debugMode && e.code === 'KeyL' && !changingRoom) { level = Math.min(5, level + 1); roomInLevel = 1; buildNextRoom(); updateHUD(); }
    if (e.code === 'KeyE' && doorDistance < 2.4) openMath();
  });
  addEventListener('keyup', e => {
    keys[e.code] = false;
    if (MOVEMENT_KEYS.includes(e.code)) {
      lastDirectionalKeySignal = performance.now();
      if (!MOVEMENT_KEYS.some(code => keys[code]) && Math.hypot(moveInput.x, moveInput.y) < .02) velocity.set(0, 0);
    }
  });
  const resetJoystick = () => {
    joystickPointerId = null;
    moveInput.x = 0;
    moveInput.y = 0;
    velocity.set(0, 0);
    ui.knob.style.transform = 'translate(-50%,-50%)';
  };
  const updateJoy = e => {
    const r = ui.joystick.getBoundingClientRect(), x = e.clientX - (r.left + r.width/2), y = e.clientY - (r.top + r.height/2);
    const d = Math.hypot(x,y), max = 38, scale = d > max ? max/d : 1;
    const nx = x*scale, ny = y*scale; ui.knob.style.transform = `translate(calc(-50% + ${nx}px), calc(-50% + ${ny}px))`;
    moveInput.x = nx/max; moveInput.y = -ny/max;
  };
  ui.joystick.addEventListener('pointerdown', e => {
    resetJoystick();
    joystickPointerId=e.pointerId;
    ui.joystick.setPointerCapture(joystickPointerId);
    updateJoy(e);
  });
  ui.joystick.addEventListener('pointermove', e => { if(e.pointerId===joystickPointerId) updateJoy(e); });
  const endJoy = e => { if (!e || e.pointerId === joystickPointerId) resetJoystick(); };
  ui.joystick.addEventListener('pointerup', endJoy); ui.joystick.addEventListener('pointercancel', endJoy); ui.joystick.addEventListener('lostpointercapture', endJoy);
  addEventListener('pointerup', endJoy, true);
  addEventListener('pointercancel', endJoy, true);
  addEventListener('pointermove', e => {
    if (e.pointerType === 'mouse' && e.pointerId === joystickPointerId && e.buttons === 0) resetJoystick();
  }, true);
  addEventListener('touchend', event => { if (event.touches.length === 0) resetJoystick(); }, { passive: true });
  addEventListener('touchcancel', event => { if (event.touches.length === 0) resetJoystick(); }, { passive: true });
  ui.jump.addEventListener('pointerdown', event => {
    event.preventDefault(); event.stopPropagation(); triggerJump();
  });
  const startSlowSteps = event => {
    event.preventDefault(); event.stopPropagation();
    if (!started || modalOpen || changingRoom) return;
    mobileSlowMode = true;
    ui.slowStep.classList.add('held');
    ui.slowStep.setPointerCapture(event.pointerId);
  };
  const endSlowSteps = event => {
    if (event) event.stopPropagation();
    mobileSlowMode = false;
    ui.slowStep.classList.remove('held');
  };
  ui.slowStep.addEventListener('pointerdown', startSlowSteps);
  ui.slowStep.addEventListener('pointerup', endSlowSteps);
  ui.slowStep.addEventListener('pointercancel', endSlowSteps);
  ui.slowStep.addEventListener('lostpointercapture', endSlowSteps);
  let lookId = null, lastX=0, lastY=0;
  ui.lookZone.addEventListener('pointerdown', e => { lookId=e.pointerId; lastX=e.clientX; lastY=e.clientY; ui.lookZone.setPointerCapture(lookId); });
  ui.lookZone.addEventListener('pointermove', e => { if(e.pointerId!==lookId) return; yaw -= (e.clientX-lastX)*.006; pitch -= (e.clientY-lastY)*.004; pitch=THREE.MathUtils.clamp(pitch,-.55,.65); lastX=e.clientX; lastY=e.clientY; });
  ui.lookZone.addEventListener('pointerup', e => { if(e.pointerId===lookId) lookId=null; });
  ui.lookZone.addEventListener('pointercancel', () => lookId=null); ui.lookZone.addEventListener('lostpointercapture', () => lookId=null);
  let drag = false, mx=0, my=0;
  renderer.domElement.addEventListener('mousedown', e => { if(started){drag=true;mx=e.clientX;my=e.clientY;} });
  addEventListener('mousemove', e => { if(!drag||modalOpen)return; yaw-=(e.clientX-mx)*.005; pitch-=(e.clientY-my)*.004; pitch=THREE.MathUtils.clamp(pitch,-.55,.65);mx=e.clientX;my=e.clientY; });
  addEventListener('mouseup', () => drag=false);
  const releaseAllControls = () => {
    drag = false;
    lookId = null;
    resetJoystick();
    stopMovement();
  };
  addEventListener('blur', releaseAllControls);
  addEventListener('focus', releaseAllControls);
  addEventListener('pagehide', releaseAllControls);
  document.addEventListener('visibilitychange', () => { if (document.hidden) releaseAllControls(); });
  document.addEventListener('contextmenu', releaseAllControls);
  addEventListener('keydown', event => { if (event.code === 'Escape') releaseAllControls(); });
}

function beep(frequency, duration) {
  if (!soundOn) return;
  const AudioCtx = window.AudioContext || window.webkitAudioContext; const ctx = new AudioCtx();
  const osc = ctx.createOscillator(), gain = ctx.createGain(); osc.frequency.value=frequency; osc.type='sine';
  gain.gain.setValueAtTime(.08,ctx.currentTime); gain.gain.exponentialRampToValueAtTime(.001,ctx.currentTime+duration);
  osc.connect(gain).connect(ctx.destination); osc.start(); osc.stop(ctx.currentTime+duration); osc.onended=()=>ctx.close();
}

function playJumpSound() {
  if (!soundOn) return;
  const AudioCtx = window.AudioContext || window.webkitAudioContext;
  const ctx = new AudioCtx();
  const osc = ctx.createOscillator(), gain = ctx.createGain();
  osc.type = 'triangle';
  osc.frequency.setValueAtTime(230, ctx.currentTime);
  osc.frequency.exponentialRampToValueAtTime(560, ctx.currentTime + .14);
  gain.gain.setValueAtTime(.001, ctx.currentTime);
  gain.gain.exponentialRampToValueAtTime(.1, ctx.currentTime + .018);
  gain.gain.exponentialRampToValueAtTime(.001, ctx.currentTime + .17);
  osc.connect(gain).connect(ctx.destination);
  osc.start();
  osc.stop(ctx.currentTime + .17);
  osc.onended = () => ctx.close();
}

ui.startButton.addEventListener('click', () => {
  started = true; ui.start.classList.remove('open'); ui.subjectScreen.classList.add('open'); modalOpen = true;
  beep(440,.12); setTimeout(()=>beep(660,.18),120);
});
ui.subjectList.addEventListener('click', event => {
  const button = event.target.closest('button[data-subject]');
  if (button) startSubject(button.dataset.subject);
});
ui.playerLogin.addEventListener('click', connectPlayer);
ui.playerName.addEventListener('keydown', event => { if (event.key === 'Enter') connectPlayer(); });
ui.playerName.addEventListener('input', () => {
  playerConnected = cleanPlayerName(ui.playerName.value).toLocaleLowerCase('pt-BR') === playerName.toLocaleLowerCase('pt-BR') && playerName.length >= 2;
  updatePlayerUI(playerConnected ? '' : 'Clique em Entrar para confirmar este jogador.');
});
ui.rankingButton.addEventListener('click', openRanking);
ui.subjectRankingButton.addEventListener('click', openRanking);
ui.closeRanking.addEventListener('click', closeRanking);
ui.rankingModal.addEventListener('click', event => { if (event.target === ui.rankingModal) closeRanking(); });
ui.interact.addEventListener('click', openMath);
ui.closeMath.addEventListener('click', closeMath);
ui.typedAnswer.addEventListener('submit', event => { event.preventDefault(); checkAnswer(ui.answerInput.value, null); });
ui.continueButton.addEventListener('click', () => {
  if (subjectFinished) showSubjectSelection();
  else { ui.levelModal.classList.remove('open'); buildNextRoom(); }
});
ui.sound.addEventListener('click', () => { soundOn=!soundOn; ui.sound.textContent=soundOn?'♪':'×'; });
addEventListener('resize', () => { camera.aspect=innerWidth/innerHeight; camera.updateProjectionMatrix(); renderer.setSize(innerWidth,innerHeight); });

restorePlayer(); init3D(); setupControls(); updateHUD();
if (import.meta.env.PROD && 'serviceWorker' in navigator) addEventListener('load', () => navigator.serviceWorker.register('/sw.js'));
